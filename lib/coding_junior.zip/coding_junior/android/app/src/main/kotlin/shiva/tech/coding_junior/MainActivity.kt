package shiva.tech.coding_junior

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
